export interface OtpValidationResponse {
    token: string;
    fullName: string;
    branchName: string;
    branchAddress: string;
    branchLat: number;
    branchLong: number;
  }